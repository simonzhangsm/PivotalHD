/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2009-03-16 23:30:31 -0700 (Mon, 16 Mar 2009) $
 **/
// Copyright (c) 2002, Eric D. Friedman All Rights Reserved.

package com.gemstone.gnu.trove;

/**
 * This object hashing strategy uses the System.identityHashCode
 * method to provide identity hash codes.  These are identical to the
 * value produced by Object.hashCode(), even when the type of the
 * object being hashed overrides that method.
 * 
 * Created: Sat Aug 17 11:13:15 2002
 *
 * @author Eric Friedman
 * @version $Id: TObjectIdentityHashingStrategy.java 24333 2009-03-17 06:30:31Z dsmith $
 */

public final class TObjectIdentityHashingStrategy implements TObjectHashingStrategy {
  
    private static final long serialVersionUID = -5193908370672076866L;

    /**
     * Delegates hash code computation to the System.identityHashCode(Object) method.
     *
     * @param object for which the hashcode is to be computed
     * @return the hashCode
     */
    public final int computeHashCode(Object object) {
        return System.identityHashCode(object);
    }

    /**
     * Compares object references for equality.
     *
     * @param o1 an <code>Object</code> value
     * @param o2 an <code>Object</code> value
     * @return true if o1 == o2
     */
    public final boolean equals(Object o1, Object o2) {
        return o1 == o2;
    }
} // TObjectIdentityHashingStrategy
