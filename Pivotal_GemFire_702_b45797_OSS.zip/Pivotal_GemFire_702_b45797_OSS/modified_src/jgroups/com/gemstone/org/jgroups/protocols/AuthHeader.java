/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2012-08-02 14:36:17 -0700 (Thu, 02 Aug 2012) $
 **/
package com.gemstone.org.jgroups.protocols;

import java.io.*;
import java.util.Properties;

import com.gemstone.gemfire.DataSerializer;
import com.gemstone.gemfire.internal.i18n.JGroupsStrings;
import com.gemstone.org.jgroups.Header;
import com.gemstone.org.jgroups.util.Streamable;

/**
 * 
 * AuthHeader stores credentials of a joiner vm to pass it to the coordinator
 * 
 * @author Yogesh Mahajan
 * @since 5.5
 * 
 */
public class AuthHeader extends Header implements Streamable {

  private static final long serialVersionUID = 1L;

  private byte[] credentials = null;

  public static final String USER_NAME = "security-username";

  public static final String PASSWORD = "security-password";
  
//  public static int MAX_CREDENTIAL_SIZE = 50000;

  public void readFrom(DataInputStream in) throws IOException,
      IllegalAccessException, InstantiationException {
    try {
      this.credentials = DataSerializer.readByteArray(in);
    }
    catch (Exception ex) {
      this.credentials = new byte[1];
    }
  }

  public void writeTo(DataOutputStream out) throws IOException {
    if (this.credentials == null) {
      this.credentials = new byte[1];
    }
    DataSerializer.writeByteArray(this.credentials, out);
  }

  public void readExternal(ObjectInput in) throws IOException,
      ClassNotFoundException {
    this.credentials = DataSerializer.readByteArray(in);
  }

  public void writeExternal(ObjectOutput out) throws IOException {
    DataSerializer.writeByteArray(this.credentials, out);
  }

  public void setCredentials(Properties credentials) {
    try {
      ByteArrayOutputStream bas = new ByteArrayOutputStream(10000);
      ObjectOutputStream oos = new ObjectOutputStream(bas);
      DataSerializer.writeProperties(credentials, oos);
//      if( bas.size() > MAX_CREDENTIAL_SIZE) {
//          throw new IllegalArgumentException(
//            JGroupsStrings.AuthHeader_SERIALIZED_CREDENTIAL_SIZE_0_EXCEEDS_MAXIMUM_OF_1.toLocalizedString(new Object[] {Integer.valueOf(bas.size()), Integer.valueOf(MAX_CREDENTIAL_SIZE) }));
//      }
      oos.flush();
      this.credentials = bas.toByteArray();
      
    }
    catch (IOException e) {
        // ignore - this will happen again when the view is serialized
        // for transmission
    }
  }

  public Properties getCredentials() {
    Properties retProp = new Properties();
    try {
      ByteArrayInputStream bas = new ByteArrayInputStream(credentials);
      ObjectInputStream ois = new ObjectInputStream(bas);
      retProp = DataSerializer.readProperties(ois);
    }
    catch (ClassNotFoundException e) {
    	
    }
    catch (IOException e) {
      // ignore - instead return properties with zero size
      // security properties are optional, if expected in
      // the other end anyway connectivity will fail.
    }
    return retProp;
  }

  @Override // GemStoneAddition
  public long size() {
      return this.credentials==null? 0 : this.credentials.length;
  }

  @Override // GemStoneAddition
  public String toString() {
    return "[AuthHeader : " + getCredentials() + "]";
  }

}
