/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2012-08-02 14:36:17 -0700 (Thu, 02 Aug 2012) $
 **/
// $Id: GossipData.java,v 1.2 2004/03/30 06:47:27 belaban Exp $

package com.gemstone.org.jgroups.stack;


import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.List;
import java.util.Vector;

import com.gemstone.gemfire.DataSerializable;
import com.gemstone.gemfire.DataSerializer;
import com.gemstone.org.jgroups.Address;



/**
 * Encapsulates data sent between GossipServer and GossipClient
 * @author Bela Ban Oct 4 2001
 */
public class GossipData implements DataSerializable {
    private static final long serialVersionUID = 309080226207432135L;
    public static final int REGISTER_REQ = 1;
    public static final int GET_REQ      = 2;
    public static final int GET_RSP      = 3;

    int     type=0;
    String  group=null;  // REGISTER, GET_REQ and GET_RSP
    Address mbr=null;    // REGISTER
    List mbrs=null;   // GET_RSP
    
    boolean hasDistributedSystem; // GemStoneAddition
    boolean floatingCoordinatorDisabled; // GemStoneAddition
    private boolean networkPartitionDetectionEnabled; // GemStoneAddition
    Vector locators;


    public GossipData() {
        ; // used for externalization
    }

    public GossipData(int type, String group, Address mbr, List mbrs, Vector locators) {
        this.type=type;
        this.group=group;
        this.mbr=mbr;
        this.mbrs=mbrs;
    }
    
    /**
     * GemStoneAddition - added a flag for whether gossip server has a
     * distributed system, and a flag for whether splitBrainDetection
     * is enabled
     */
    public GossipData(int type, String group, Address mbr, List mbrs,
        boolean hasDistributedSystem, boolean floatingDisabled,
        boolean networkPartitionDetectionEnabled, Vector locators) {
        this.type=type;
        this.group=group;
        this.mbr=mbr;
        this.mbrs=mbrs;
        this.hasDistributedSystem = hasDistributedSystem;
        this.floatingCoordinatorDisabled = floatingDisabled;
        this.networkPartitionDetectionEnabled = networkPartitionDetectionEnabled;
        this.locators = locators;
    }
    

    public int     getType()  {return type;}
    public String  getGroup() {return group;}
    public Address getMbr()   {return mbr;}
    public List getMbrs()  {return mbrs;}
    
    // GemStoneAddition
    public boolean getHasDistributedSystem() {
      return hasDistributedSystem;
    }
    
    // GemStoneAddition
    public boolean getFloatingCoordinatorDisabled() {
      return this.floatingCoordinatorDisabled;
    }
    
    // GemStoneAddition
    public boolean getNetworkPartitionDetectionEnabled() {
      return this.networkPartitionDetectionEnabled;
    }

    @Override // GemStoneAddition
    public String toString() {
        StringBuffer sb=new StringBuffer();
        sb.append(type2String(type));
        switch(type) {
        case REGISTER_REQ:
            sb.append(" group=" + group + ", mbr=" + mbr /*+ ", locators=" + this.locators*/);
            break;

        case GET_REQ:
            sb.append(" group=" + group /*+ ", locators=" + this.locators*/);
            break;

        case GET_RSP:
            sb.append(" group=" + group + ", mbrs=" + mbrs
                + " hasDS=" + hasDistributedSystem + " coordinator="+mbr+" locators=" + this.locators); // GemStoneAddition
            break;
 
        }

        return sb.toString();
    }


    public static String type2String(int t) {
        switch(t) {
        case REGISTER_REQ: return "REGISTER_REQ";
        case GET_REQ:      return "GET_REQ";
        case GET_RSP:      return "GET_RSP";
        default:           return "<unknown>";
        }
    }

    
    public void toData(DataOutput out) throws IOException {
      out.writeInt(type);
      out.writeUTF(group==null? "" : group);
      DataSerializer.writeObject(mbr, out);
      DataSerializer.writeObject(mbrs, out);
      //DataSerializer.writeObject(this.locators, out);
      out.writeBoolean(hasDistributedSystem);
      out.writeBoolean(this.floatingCoordinatorDisabled);
      out.writeBoolean(this.networkPartitionDetectionEnabled);
    }



    public void fromData(DataInput in) throws IOException,
        ClassNotFoundException {
      type=in.readInt();
      group=in.readUTF();
      mbr= (Address) DataSerializer.readObject(in);
      mbrs=(List ) DataSerializer.readObject(in);
      //this.locators = (Vector)DataSerializer.readObject(in);
      hasDistributedSystem = in.readBoolean();
      this.floatingCoordinatorDisabled = in.readBoolean();
      this.networkPartitionDetectionEnabled = in.readBoolean();
    }

    
    

}

