/*=========================================================================
 * Copyright (c) 2013 VMware, Inc. All rights reserved. This product 
 * is protected by U.S. and international copyright and intellectual 
 * property laws. VMware products are covered by one or more patents listed 
 * at http://www.vmware.com/go/patents.  
 *=========================================================================
 */

package com.gemstone.gnu.trove;

/**
 * Interface to gather hash statistics for trove map reads/writes etc.
 * 
 * @author swale
 * @since gfxd 1.0
 */
public interface HashingStats {

  /**
   * Returns the current NanoTime or, if clock stats are disabled, zero.
   */
  long getNanoTime();

  /**
   * Increment the statistic indicating a hash collision.
   */
  void incQueryResultsHashCollisions();

  /**
   * Increment the statistic for time required to lookup map for hash
   * collisions.
   */
  void endQueryResultsHashCollisionProbe(long start);
}
