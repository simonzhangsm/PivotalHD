/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date$
 **/



package com.gemstone.org.jgroups;

/**
 * Holds version information for JGroups.
 */
public class Version {
    /** changed from 2.2.9.1.2 to 2.2.9.1.3 for gemfire 5.7 */
    /** changed from 2.2.9.1.3 to 2.2.9.1.5 for gemfire 7.0 */
    public static final String description="2.2.9.1.3"; // GemStoneAddition - was 2.2.9.1
    /** changed from 22912 to 22913 for gemfire 5.7 */
    /** changed from 22913 to 22920 for gemfire 7.0 */
    public static final short version=22920; // GemStoneAddition - was 2291
    public static final String cvs="$Id: Version.java,v 1.27 2005/12/27 14:52:48 belaban Exp $";

    /**
     * Prints the value of the description and cvs fields to System.out.
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("\nVersion: \t" + description);
        System.out.println("CVS: \t\t" + cvs);
        System.out.println("History: \t(see doc/history.txt for details)\n");
    }

    /**
     * Returns the catenation of the description and cvs fields.
     * @return String with description
     */
    public static String printDescription() {
        return "JGroups " + description + "[ " + cvs + "]";
    }

    /**
     * Returns the version field as a String.
     * @return String with version
     */
    public static String printVersion() {
        return Short.valueOf(version).toString();
    }

    /**
     * Compares the specified version number against the current version number.
     * @param v short
     * @return Result of == operator.
     */
    public static boolean compareTo(short v) {
        return version == v;
    }
}
