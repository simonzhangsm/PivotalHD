/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date$
 **/
// $Id: GossipServer.java,v 1.10 2005/06/09 18:31:02 belaban Exp $

package com.gemstone.org.jgroups.stack;

import com.gemstone.gemfire.InternalGemFireException;
import com.gemstone.gemfire.cache.GemFireCache;
import com.gemstone.gemfire.distributed.DistributedSystem;
import com.gemstone.gemfire.distributed.internal.DistributionManager;
import com.gemstone.gemfire.distributed.internal.InternalDistributedSystem;
import com.gemstone.gemfire.distributed.internal.membership.InternalDistributedMember;
import com.gemstone.gemfire.distributed.internal.membership.jgroup.JGroupMember;
import com.gemstone.gemfire.internal.SocketCreator;
import com.gemstone.gemfire.internal.admin.remote.DistributionLocatorId;
import com.gemstone.gemfire.internal.i18n.JGroupsStrings;
import com.gemstone.org.jgroups.Address;
import com.gemstone.org.jgroups.protocols.TCPGOSSIP;
import com.gemstone.org.jgroups.stack.tcpserver.TcpHandler;
import com.gemstone.org.jgroups.stack.tcpserver.TcpServer;
import com.gemstone.org.jgroups.util.GemFireTracer;

import java.io.Externalizable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import com.gemstone.gemfire.internal.Version;
import com.gemstone.gemfire.internal.VersionedObjectInput;
import com.gemstone.gemfire.internal.VersionedObjectOutput;
import com.gemstone.gnu.trove.TIntIntHashMap;
import com.gemstone.gnu.trove.TIntIntIterator;


/**
 * Maintains a cache of member addresses for each group. There are essentially 2 functions: get the members for
 * a given group and register a new member for a given group. Clients have to periodically renew their
 * registrations (like in JINI leasing), otherwise the cache will be cleaned periodically (oldest entries first).<p>
 * The server should be running at a well-known port. This can be done by for example adding an entry to
 * /etc/inetd.conf on UNIX systems, e.g. <code>gossipsrv stream tcp nowait root /bin/start-gossip-server</code>.
 * <code>gossipsrv</code> has to be defined in /etc/services and <code>start-gossip-server</code> is a script
 * which starts the GossipServer at the well-known port (define in /etc/services). The protocol between GossipServer
 * and GossipClient consists of REGISTER_REQ, GET_MEMBERS_REQ and GET_MEMBERS_RSP protocol data units.<p>
 * The server does not spawn a thread/request, but does all of its processing on the main thread. This should not
 * be a problem as all requests are short-lived. However, the server would essentially cease processing requests
 * if a telnet connected to it.<p>
 * Requires JDK >= 1.3 due to the use of Timer
 * deprecated Use GossipRouter instead // GemStoneAddition - remove deprecation of GossipServer for now.  The router has too much baggage.
 * @author Bela Ban Oct 4 2001
 * 
 * GemStoneAddition - factored out TcpServer server code into TcpServer.java. This gossip server is now a handler which
 * can be plugged into the TcpServer.
 */
public class GossipServer implements TcpHandler {
  
  public final static int GOSSIPVERSION = TcpServer.getCurrentGossipVersion();
  // OLDGOSSIPVERSION is only used in _getVersionForAddress in GossipClient.
  public final static int OLDGOSSIPVERSION = TcpServer.getOldGossipVersion();
  // public final static int FILE_FORMAT_VERSION = 1003 - GF 7.0.1;
  public static int FILE_FORMAT_VERSION = 1004; // added ip address
  private static/* GemStoneAddition */ final TIntIntHashMap FILE_FORMAT_TO_GEMFIRE_VERSION_MAP = new TIntIntHashMap();
  public final static boolean LOCATOR_DISCOVERY_DISABLED = Boolean.getBoolean("gemfire.disable-locator-discovery");

    // change this name to prevent gemfire from connecting to versions having a different name
    public static final String CHANNEL_NAME = "GF7";

    /**
     * GemStoneAddition (comment)
     * <p>
     * Table where the keys are {@link String}s (group names) and the
     * values are {@link List}s of {@link com.gemstone.org.jgroups.stack.GossipServer.Entry}s.
     * <p>
     * Since <code>GossipServer.CacheCleaner</code> accesses this object concurrently,
     * updates to this field must be synchronized on the instance.
     * 
     * @see #sweep()
     * @see #addMember(String, Address)
     */
    final Map groups=new HashMap();  // groupname - list of Entry's
    static long EXPIRY_TIME_DEFAULT = 30000; // GemStoneAddition
    long expiry_time=EXPIRY_TIME_DEFAULT;       // time (in msecs) until a cache entry expires
    CacheCleaner cache_cleaner=null;      // task that is periodically invoked to sweep old entries from the cache
    // TODO use SystemTimer?
    Timer timer;   // start as daemon thread, so we won't block on it upon termination
    
    protected final GemFireTracer log=GemFireTracer.getLog(getClass());
    
    File gossipFile; // GemStoneAddition
    boolean floatingCoordinatorDisabled; // GemStoneAddition
    boolean networkPartitionDetectionEnabled; // GemStoneAddition
    private InetAddress bind_address;
    private int port;
    private File stateFile;
    private String locatorString;

    /** GemStoneAddition - the current membership coordinator */
    private Address coordinator;
    private Vector locators;
    private Address localAddress; // added in 7.5 for bug #30341
    private Object localAddressSync = new Object();
    private boolean withDS; // true if there will be a distributed system

    /**
     * GemStoneAddition - Initialize versions map.
     * Warning: This map must be compatible with all GemFire versions being
     * handled by this member "With different GOSSIPVERION". If GOSSIPVERIONS
     * are same for then current GOSSIPVERSION should be used.
     *
     * @since 7.1
     */
    static {
      FILE_FORMAT_TO_GEMFIRE_VERSION_MAP.put(1003, Version.GFE_701.ordinal());
      FILE_FORMAT_TO_GEMFIRE_VERSION_MAP.put(1004, Version.CURRENT_ORDINAL);
    }

    /**
     * 
     * @param port              number of the tcp/ip server socket port to use
     * @param expiry_time       time until registration entries expire
     * @param bind_address      network address to bind to
     * @param stateFile         name of the file to persist state to/recover from
     * @param locatorString     location of other locators (bootstrapping, failover)
     * @param floatingCoordinatorDisabled       true if Coordinator can only be in Locators
     * @param networkPartitionDetectionEnabled true if network partition detection is enabled
     * @param withDS            true if a distributed system has been or will be started
     */
    public GossipServer(int port, long expiry_time,
                        InetAddress bind_address,
                        File stateFile,
                        String locatorString,
                        boolean floatingCoordinatorDisabled,
                        boolean networkPartitionDetectionEnabled,
                        boolean withDS)
    {
      this.port = port;
      this.bind_address = bind_address;
      this.expiry_time=expiry_time;
      this.withDS = withDS;
      this.floatingCoordinatorDisabled = floatingCoordinatorDisabled;
      this.networkPartitionDetectionEnabled = networkPartitionDetectionEnabled;
      this.stateFile = stateFile;
      this.locatorString = locatorString;
      if (this.locatorString == null || this.locatorString.length() == 0) {
        this.locators = new Vector();
      } else {
        this.locators = TCPGOSSIP.createInitialHosts(this.locatorString);
      }
    }
    
    public void restarting(DistributedSystem ds, GemFireCache cache) {
    }

    
    /** recover gossip state from another locator or from the given stateFile
     * 
     * @param sFile
     *          a file containing gossipserver state from a past run
     * @param locatorsString
     *          a GemFire distributed system locators string
     */
    private void recover(File sFile, String locatorsString)
    {
      // First recover from file to find out correct versions of GossipServers 
      recoverFromFile(sFile);
      // Send getMembers request with correct GemFire version number.
      recoverFromOthers(locatorsString);
    }
    
    /** GemStoneAddition - get gossip state from another locator.  Return
     * true if we're able to contact another locator and get its state.
     * @param locatorsString
     *   a string with locator specs in GemFire form
     */
    private boolean recoverFromOthers(String locatorsString) {
      String myAddr;
      String myAddr2 = null;
      if (locatorsString != null && locatorsString.length() > 0) {
        if (this.bind_address == null) {
          try {
            myAddr = SocketCreator.getLocalHost().getHostName();
            myAddr2 = SocketCreator.getLocalHost().getCanonicalHostName();
          }
          catch (UnknownHostException ue) {
            log.getLogWriterI18n().warning(JGroupsStrings.GossipServer_UNABLE_TO_RESOLVE_LOCAL_HOST_NAME, ue);
            myAddr = "localhost";
          }
        }
        else {
          myAddr = this.bind_address.getHostAddress();
          myAddr2 = this.bind_address.getCanonicalHostName();
        }
        StringTokenizer st = new StringTokenizer(locatorsString, ",");
        while (st.hasMoreTokens()) {
          String l = st.nextToken();
          DistributionLocatorId locId = new DistributionLocatorId(l);
          if (!locId.isMcastId()) {
            String otherAddr = locId.getBindAddress();
            String otherAddr2 = null;
            if (otherAddr != null) {
              otherAddr = otherAddr.trim();
            }
            if (otherAddr == null || otherAddr.length() == 0) {
              otherAddr = locId.getHost().getHostName();
              otherAddr2 = locId.getHost().getCanonicalHostName(); // some people use fqns
            }
            if ( !( (
                     otherAddr.equals(myAddr) || (otherAddr2 != null && otherAddr2.equals(myAddr)) || (myAddr2 != null  && myAddr2.equals(otherAddr2))
                     )
                   && locId.getPort() == this.port) ) {
              log.getLogWriterI18n().info(JGroupsStrings.GossipServer_0__1__ATTEMPTING_TO_GET_STATE_FROM__2__3_, new Object[] {myAddr, Integer.valueOf(this.port), otherAddr, Integer.valueOf(locId.getPort())});
              if (recover(otherAddr, locId.getPort())) {
                return true;
              }
            }
          }
        } // while()
      } // if (locatorsString)

      return false;
    }
    
    /** try to recover gossip state from another locator */
    private boolean recover(String address, int serverPort) {

      // Contact existing locator first to find out all members in system.
      GossipClient gc = new GossipClient(
          new IpAddress(address, serverPort), 20000);
      List info = gc.getMembers(CHANNEL_NAME, (Address)null, false, 15000);

      if (gc.getResponsiveServerCount() > 0) {
        List mbrs = new VersionedEntryList(info.size());
        for (int i=0; i<info.size(); i++) {
          mbrs.add(new Entry((Address)info.get(i)));
        }
        // GemStoneAddition (comment)
        // Note that CacheCleaner has not yet started, so it is
        // not necessary to synchronize this update.
        groups.put(CHANNEL_NAME, mbrs);
        log.getLogWriterI18n().info(JGroupsStrings.GossipServer_INITIAL_DISCOVERY_SET_IS_0,
            mbrs);
        processLocators(log, locators, gc.getGossip_servers());
        return true;
      }
      return false;
    }
    
    /** recover gossip state from the given file
     * 
     * @param sFile the file containing gossip state from a previous run
     * @return true if state was recovered from disk 
     */
    private boolean recoverFromFile(File sFile) {
      if (sFile.exists()) {
        log.getLogWriterI18n().info(JGroupsStrings.GossipServer_RECOVERING_STATE_FROM__0, sFile);
        FileInputStream fis = null;
        try {
          VersionedEntryList members = null;
          fis = new FileInputStream(sFile);
          ObjectInput ois = new ObjectInputStream(fis);
          try { // GemStoneAddition assure stream closure
            int fileversion = ois.readInt();
            log.info("Discovery set was written with file version " + fileversion);
            if (fileversion <= FILE_FORMAT_VERSION) {
              short gfVersion = (short)FILE_FORMAT_TO_GEMFIRE_VERSION_MAP.get(fileversion);
              Version gemFireVersion = Version.fromOrdinalNoThrow(gfVersion, false);
              if ( gemFireVersion != null) {
                log.getLogWriterI18n().info(JGroupsStrings.DEBUG, "Discovery set was written with " + gemFireVersion);
                ois = new VersionedObjectInput(ois, gemFireVersion);
              } else {
                return false;
              }
            } else {
              return false;
            }
            InetAddress addr = (InetAddress)ois.readObject();
            if (addr != null && this.bind_address != null && !addr.equals(this.bind_address)) {
              return false;
            }
            members = new VersionedEntryList();
            members.readExternal(ois);
//            this.log.getLogWriterI18n().fine(
//                "Recovered members: " + Arrays.toString(members.toArray()));
          }
          finally {
            ois.close();
          }
          // GemStoneAddition (comment)
          // Note that CacheCleaner has not started yet, so it
          // is not necessary to synchronize this update to groups.
          groups.put(CHANNEL_NAME, members);
          log.getLogWriterI18n().info(JGroupsStrings.GossipServer_INITIAL_DISCOVERY_SET_IS_0,
              members);
          return true;
        }
        catch (Exception e) {
          e.printStackTrace();
          log.getLogWriterI18n().warning(JGroupsStrings.GossipServer_UNABLE_TO_RECOVER_LOCATOR_REGISTRY_FROM__0, sFile, e);
          
          // GemStoneAddition: close the stream before attempting to delete the stateFile,
          // otherwise intelligent file systems (like Windows) will not delete the file.
          if (fis != null) {
            try { fis.close(); } catch (IOException e2) { }
          }
          
          // GemStoneAddition: check return of delete()
          if (!sFile.delete() && sFile.exists()) {
            log.getLogWriterI18n().warning(JGroupsStrings.GossipServer_UNABLE_TO_DELETE_REGISTRY_FILE_DISABLING_REGISTRY_PERSISTENCE);
            this.gossipFile = null;
          }
//          try {
//            stateFile.delete();
//          }
//          catch (Exception e2) {
//            log.getLogWriter().warning("Unable to delete registry file. Disabling registry persistence", e2);
//            this.gossipFile = null;
//          }
        }
        finally {
          // GemStoneAddition make sure the streams are closed
          if (fis != null) {
            try { fis.close(); } catch (IOException e) { }
          }
        }
      }
      return false;
    }

    /* ----------------------------------- Private methods ----------------------------------- */

    public void init(TcpServer server) {
      this.timer = new Timer(true);
      if (log.getLogWriterI18n().fineEnabled()) {
        this.log.getLogWriterI18n().fine("Recovering from state file: " + stateFile);
      }
      recover(stateFile, locatorString);
      cache_cleaner=new CacheCleaner();
      timer.schedule(cache_cleaner, expiry_time, expiry_time);
      this.gossipFile = stateFile;
    }

    
    /**
     * compare the given list with the locators vector.  If there are
     * any new ones, add them.
     * 
     * @param myLocators the existing locators
     * @param otherLocators the locators received from someone else
     * @return true if otherLocators has different locators than myLocators
     */
    public static boolean processLocators(GemFireTracer log, Vector myLocators, Vector otherLocators) {
      if (LOCATOR_DISCOVERY_DISABLED) {
        return false;
      }
      if (otherLocators == null) {
        return true;
      }
      synchronized(myLocators) {
        List newLocators = null;
        for (Iterator e = otherLocators.iterator(); e.hasNext(); ) {
          Address a = (Address)e.next();
          if (!myLocators.contains(a)) {
            if (newLocators == null) {
              newLocators = new LinkedList();
            }
            newLocators.add(a);
          }
        }
        if (newLocators != null) {
          myLocators.addAll(newLocators);
          return true;
        } else {
          return myLocators.size() == otherLocators.size();
        }
      }
    }

    /**
     Process the gossip request. Return a gossip response or null if none.
     */
    public synchronized Object processRequest(Object request) {
      if(!(request instanceof GossipData)) {
        throw new InternalGemFireException("Expected gossipData, got " + request.getClass());
      }
      GossipData gossip = (GossipData) request;
        String group;
        Address mbr = null;

//        if(gossip == null) return null; GemStoneAddition not possible
        if(log.isDebugEnabled()) log.trace(gossip.toString()); // GemStoneAddition - changed to trace()
        switch(gossip.getType()) {
            case GossipData.REGISTER_REQ:
                group=gossip.getGroup();
                mbr=gossip.getMbr();
                if(group == null || mbr == null) {
                    if(log.isErrorEnabled()) log.error(JGroupsStrings.GossipServer_GROUP_OR_MEMBER_IS_NULL_CANNOT_REGISTER_MEMBER);
                    return null;
                }
                boolean differed = processLocators(log, locators, gossip.locators);
                return processRegisterRequest(group, mbr, differed);

            case GossipData.GET_REQ:
                group=gossip.getGroup();
                mbr = gossip.getMbr();
                if(group == null) {
                    if(log.isErrorEnabled()) log.error(JGroupsStrings.GossipServer_GROUP_IS_NULL_CANNOT_GET_MEMBERSHIP);
                    return null;
                }
                differed = processLocators(log, locators, gossip.locators);
                return processGetRequest(group, mbr, differed); // GemStoneAddition - add mbr to group on a get req to make atomic

            case GossipData.GEMFIRE_VERSION:
              return processVersionRequest(); // GemStoneAddition - add mbr to group on a get req to make atomic

            case GossipData.GET_RSP:  // should not be received
                if(log.isWarnEnabled()) log.warn(JGroupsStrings.GossipServer_RECEIVED_A_GET_RSP_SHOULD_NOT_BE_RECEIVED_BY_SERVER);
                return null;
	    
            default:
                if(log.isWarnEnabled()) log.warn(
                    JGroupsStrings.GossipServer_RECEIVED_UNKOWN_GOSSIP_REQUEST_GOSSIP_0
                    .toLocalizedString(gossip));
                return null;
        }
    }

    
    public void endRequest(Object request,long startTime) { }
    public void endResponse(Object request,long startTime) { }
    
    /**
     * GemStoneAddition - internet protocol version compatibility check
     * @param addr the address of the other member
     * @return true if the member is using the same version of IP we are
     */
    private boolean checkCompatibility(Address addr) {
      if (this.bind_address != null && addr != null) {
        return this.bind_address.getClass() == ((IpAddress)addr).getIpAddress().getClass();
      }
      return true;
    }

    GossipData processRegisterRequest(String group, Address mbr, boolean sendLocators) {
        if (!checkCompatibility(mbr)) {
          log.getLogWriterI18n().warning(JGroupsStrings.GossipServer_RECEIVED_REGISTRATION_REQUEST_FROM_MEMBER_USING_INCOMPATIBLE_INTERNET_PROTOCOL_0, mbr);
        }
        addMember(group, mbr);
        persistState();
        GossipData rsp = new GossipData();
        if (sendLocators) {
          rsp.locators = new Vector(this.locators);
        }

        // bug #30341 - wait until the local address is known before replying to a registration
        if (withDS) {
          try {
            synchronized(this.localAddressSync) {
              while (this.localAddress == null /*&& this.hasDistributedSystem()*/) {
                this.localAddressSync.wait();
              }
            }
          } catch (InterruptedException e) {
            return null;
          }
        }
        rsp.localAddress = this.localAddress;
        
        return rsp;
    }

    // GemStoneAddition - added mbr parameter.  Member is added to group on
    //            a get() request to make it atomic.  Bug 30341
    GossipData processGetRequest(String group, Address mbr, boolean sendLocators) {
        if (!checkCompatibility(mbr)) {
          log.getLogWriterI18n().warning(JGroupsStrings.GossipServer_RECEIVED_GETMEMBERS_REQUEST_FROM_MEMBER_USING_INCOMPATIBLE_INTERNET_PROTOCOL_0, mbr);
        }
        GossipData ret=null;
        List mbrs;
        synchronized (this) { // fix for bug 30341
          mbrs=getMembers(group);
          if (mbr != null) {
            addMember(group, mbr);
            persistState();
          }
        }
        
        if (withDS) {
          // bug #30341 - wait until the local address is known before replying to a registration
          try {
            synchronized(this.localAddressSync) {
              while (this.localAddress == null /*&& this.hasDistributedSystem()*/) {
                this.localAddressSync.wait();
              }
            }
          } catch (InterruptedException e) {
            return null;
          }
        }
        
        ret=new GossipData(GossipData.GET_RSP, group, this.coordinator, mbrs,
            this.hasDistributedSystem(), this.floatingCoordinatorDisabled,
            this.networkPartitionDetectionEnabled, (sendLocators?this.locators:null), this.localAddress);

        if(DistributionManager.VERBOSE) {
          log.getLogWriterI18n().info(
              JGroupsStrings.ONE_ARG,
              "get-members response = " + ret); // GemStoneAddition
        }
        
        return ret;
    }

    GossipData processVersionRequest() {
      
      GossipData ret = new GossipData(GossipData.GEMFIRE_VERSION, null, null, null, null);
      ret.versionOrdinal = Version.CURRENT_ORDINAL;

      if(DistributionManager.VERBOSE) {
        log.getLogWriterI18n().info(
            JGroupsStrings.ONE_ARG,
            "version response = " + ret.versionOrdinal); // GemStoneAddition
      }
      
      return ret;
    }

    private void persistState() {
      if (gossipFile != null) {
        VersionedEntryList members;
        synchronized (groups) { // GemStoneAddition
          members = (VersionedEntryList)groups.get(CHANNEL_NAME);
          if (members == null) {
            members = new VersionedEntryList();
            groups.put(CHANNEL_NAME, members);
          }
        }
        if (!gossipFile.delete() && gossipFile.exists()) {
          log.getLogWriterI18n().warning(
            JGroupsStrings.GossipServer_UNABLE_TO_DELETE_0, gossipFile.getAbsolutePath());
        }
//        this.log.getLogWriterI18n().fine("Persisting to file: "+ gossipFile + " members: " + members);
        try {
          FileOutputStream fos = null;
          ObjectOutputStream oos = null;
          VersionedObjectOutput vos = null;
          try { // GemStoneAddition assure stream closure
            fos = new FileOutputStream(gossipFile);
            oos = new ObjectOutputStream(fos);
            vos = new VersionedObjectOutput(oos, Version.fromOrdinal((short)
                FILE_FORMAT_TO_GEMFIRE_VERSION_MAP.get(FILE_FORMAT_VERSION),
                false));
            vos.writeInt(FILE_FORMAT_VERSION);
            vos.writeObject(this.bind_address);
            synchronized (members) { // GemStoneAddition members needs to be consistent
              members.writeExternal(vos);
            }
            vos.flush();
            oos.flush();
            fos.flush();
          }
          finally {
            if (vos != null) {
              vos.close();
            }

            if (oos != null) {
              oos.close();
            }
            // In case the FileOutputStream got created but the ObjectOutputStream failed...
            if (fos != null) {
              fos.close();
            }
          }
        }
        catch (Exception e) {
          log.getLogWriterI18n().warning(JGroupsStrings.GossipServer_ERROR_WRITING_LOCATOR_STATE_TO_DISK__STATE_STORAGE_IS_BEING_DISABLED, e);
          this.gossipFile = null;
        }
      }
    }


    /**
     * note that it is okay for this to return false if this locator will have a
     * DS but it has not yet been created
     * @return true if there is a distributed system running in this vm
     */
    boolean hasDistributedSystem() {
      return withDS || InternalDistributedSystem.unsafeGetConnectedInstance() != null;
    }
    
    /**
     Adds a member to the list for the given group. If the group doesn't exist, it will be created. If the member
     is already present, its timestamp will be updated. Otherwise the member will be added.
     @param group The group name. Guaranteed to be non-null
     @param mbr The member's address. Guaranteed to be non-null
     */
    void addMember(String group, Address mbr) {
        List mbrs;
        synchronized (groups) { // GemStoneAddition
          mbrs =(List) groups.get(group);
        }
        Entry entry;

        if(mbrs == null) {
            mbrs=new VersionedEntryList();
            mbrs.add(new Entry(mbr));
            synchronized (groups) { // GemStoneAddition
              groups.put(group, mbrs);
            }
            //GemStoneAddition - set to Trace level
             if(log.isTraceEnabled()) log.trace("added " + mbr + " to discovery set for " + group + " (new group)");
        }
        else {
            entry=findEntry(mbrs, mbr);
            if(entry == null) {
                entry=new Entry(mbr);
                synchronized (mbrs) {
                  mbrs.add(entry);
                }
                //GemStoneAddition - set to Trace level
                 if(log.isTraceEnabled()) log.trace("added " + mbr + " to discovery set for " + group);
            }
            else {
                entry.mbr = mbr;
                entry.update();
                //GemStoneAddition - set to Trace level
                 if(log.isTraceEnabled()) log.trace("updated discovery set entry " + entry);
            }
        }
    }


    /** test hook for GemFire - see how many members are in the discovery set */
    public int getMemberCount() {
      List mbrs = getMembers(CHANNEL_NAME);
      if (mbrs == null) {
        return -1;
      }
      return mbrs.size();
    }
    
    
    List getMembers(String group) {
        List ret=null;
        List mbrs;
        synchronized (groups) { // GemStoneAddition
          mbrs =(List) groups.get(group);
        }

        if(mbrs == null)
            return null;
        synchronized (mbrs) {
          ret=new ArrayList(mbrs.size());
          for(int i=0; i < mbrs.size(); i++)
            ret.add(((Entry) mbrs.get(i)).mbr);
        }
        return ret;
    }


    Entry findEntry(List mbrs, Address mbr) {
        Entry entry=null;

        synchronized (mbrs) { // GemStoneAddition
          for(int i=0; i < mbrs.size(); i++) {
            entry=(Entry) mbrs.get(i);
            if(entry.mbr != null && entry.mbr.equals(mbr))
                return entry;
          }
        }
        return null;
    }


    /**
     * Remove expired entries (entries older than EXPIRY_TIME msec).
     */
    synchronized void sweep() {
        long current_time=System.currentTimeMillis(), diff;
        int num_entries_removed=0;
        String key=null;
        List val;
        Entry entry;

      boolean done; // GemStoneAddition - fix for bug 31361
      do {
        done = true;
        try {
  
          for(Iterator e=groups.keySet().iterator(); e.hasNext();) {
              key=(String) e.next();
              val=(List) groups.get(key);
              if(val != null) {
                // GemStoneAddition -- don't use iterator.  It is live
                // and can fail due to concurrent modification.  Instead,
                // safely create a copy of the list and iterate over _that_
                ArrayList listCopy;
                synchronized (val) {
                  listCopy = new ArrayList(val);
                }
                  for(Iterator it=listCopy.iterator() /*val.listIterator()*/; it.hasNext();) {
                      entry=(Entry) it.next();
                      diff=current_time - entry.timestamp;
                      if(entry.timestamp + expiry_time < current_time) {
//                          it.remove();
                          val.remove(entry);
                          if(log.isTraceEnabled()) log.trace("removed member " + entry +
                                                                 " from discovery set " + key + '(' + diff + " msecs old)");
                          num_entries_removed++;
                      }
                  }
              }
          }
  
        } catch (ConcurrentModificationException ex) {
          done = false;
        }
      } while (!done);

      if(num_entries_removed > 0)
        if(log.isInfoEnabled()) log.info(JGroupsStrings.GossipServer_DONE_REMOVED__0__DISCOVERY_ENTRIES, num_entries_removed);
    }
    
    public void shutDown() {
      this.timer.cancel();
    }

    /* -------------------------------- End of Private methods ----------------------------------- */

    /**
     *   Maintains the member address plus a timestamp. Used by CacheCleaner thread to remove old entries.
     */
    private static class Entry {
        Address mbr=null;
        long timestamp=0;

        Entry(Address mbr) {
            this.mbr=mbr;
            update();
        }

        void update() {
            timestamp=System.currentTimeMillis();
        }

        @Override // GemStoneAddition
        public boolean equals(Object other) {
          // GemStoneAddition - this was assuming the argument was an address,
          // which caused removals on the containing collection to fail
            if(mbr != null && other != null) {
              if (other instanceof Address) {
                return mbr.equals(other);
              }
              else if (other instanceof Entry) {
                return mbr.equals(((Entry)other).mbr);
              }
            }
            return false;
        }

        @Override // GemStoneAddition
        public int hashCode() { // GemStoneAddition
          return 0; // TODO more efficient implementation :-)
        }
        
        @Override // GemStoneAddition
        public String toString() {
            return "mbr=" + mbr;
        }

        public void readExternal(ObjectInput in) throws IOException,
            ClassNotFoundException {
          this.mbr = new IpAddress();
          this.mbr.readExternal(in);
          update();
        }

        public void writeExternal(ObjectOutput out) throws IOException {
          mbr.writeExternal(out);
        }
    }

    // GemStoneAddition
    private static class VersionedEntryList extends ArrayList<Entry> implements Externalizable {

      // For testing only
      private int TEST_BYTES = 1;

      public VersionedEntryList(int size) {
        super(size);
      }

      public VersionedEntryList() {
        super();
      }

      @Override
      public void readExternal(ObjectInput in) throws IOException,
          ClassNotFoundException {

        // File format version from GF7.0.X to 7.1.X has been changed.
        if (TcpServer.isTesting && in instanceof VersionedObjectInput) {
          VersionedObjectInput vis = (VersionedObjectInput)in;
          short gfVersion = vis.getVersion().ordinal();
          int newFileVersion = getFileVersionForOrdinal(Version.GFE_71.ordinal());
          int oldFileVersion = getFileVersionForOrdinal(gfVersion);
          if (oldFileVersion < newFileVersion) {
            if(in.readInt() != TEST_BYTES){
              throw new IOException("Read integer is not TEST_BYTES ");
            }
          }
        }
        
        int size = in.readInt();
        for (int i=0; i<size; i++) {
          Entry entry = new Entry(null);
          entry.readExternal(in);
          add(entry);
        }
      }

      @Override
      public void writeExternal(ObjectOutput out) throws IOException {

     // For test purpose only. File format version from GF7.0.X to 7.1.X has been changed.
        if (TcpServer.isTesting && out instanceof VersionedObjectOutput) {
          VersionedObjectOutput vos = (VersionedObjectOutput)out;
          short gfVersion = vos.getVersion().ordinal();
          int newFileVersion = getFileVersionForOrdinal(Version.GFE_71.ordinal());
          int oldFileVersion = getFileVersionForOrdinal(gfVersion);
          if (oldFileVersion < newFileVersion) {
            out.writeInt(TEST_BYTES);
          }
        }

        out.writeInt(this.size());
        Iterator<Entry> itr = this.iterator();
        while(itr.hasNext()) {
          Entry entry = itr.next();
          entry.writeExternal(out);
        }
      }
    }

  /**
   * Returns File Version for older Gemfire versions. If we have mappings
   * "[1000 -> GF_70], [1001 -> GF_71]" and passed version is GF_701 and there
   * is no mapping for GF_701 we will return 1000 which is lower closest
   * possible to GF_701.
   * 
   * @param ordinal
   * @return gossip version
   */
    public static int getFileVersionForOrdinal(short ordinal) {

      // Sanity check
      short closest = -1;
      int closestFV = GossipServer.FILE_FORMAT_VERSION;
      if (ordinal <= Version.CURRENT_ORDINAL) {
        TIntIntIterator itr = GossipServer.FILE_FORMAT_TO_GEMFIRE_VERSION_MAP.iterator();
        while (itr.hasNext()) {
          itr.advance();
          short o = (short)itr.value();
          if (o == ordinal) {
            return itr.key();
          } else if (o < ordinal && o > closest ) {
            closest = o;
            closestFV = itr.key();
          }
        }
      }

      return closestFV;
    }

    /**
     * Periodically sweeps the cache and removes old items (items that are older than EXPIRY_TIME msecs)
     */
    class CacheCleaner extends TimerTask  {

      @Override // GemStoneAddition
        public void run() {
            sweep();
        }

    }

    /**
     * @param coordinator the coordinator to set
     */
    public void setCoordinator(Address coordinator) {
      this.coordinator = coordinator;
    }
    
    /**
     * @param address the address of this member
     */
    public void setLocalAddress(Address address) {
      synchronized(this.localAddressSync) {
        this.localAddress = address;
        this.localAddressSync.notifyAll();
      }
    }
    
    /**
     * @param daddress the address of the distributed system
     */
    public void setLocalAddress(InternalDistributedMember daddress) {
      Address jgroupsAddress = ((JGroupMember)daddress.getNetMember()).getAddress();
      setLocalAddress(jgroupsAddress);
    }

    /**  GemStoneAddition - we don't want this main method
    public static void main(String[] args)
            throws java.net.UnknownHostException {
        String arg;
        int port=7500;
        long expiry_time=30000;
        GossipServer gossip_server=null;
        InetAddress address=null;
        for(int i=0; i < args.length; i++) {
            arg=args[i];
            if("-help".equals(arg)) {
                System.out.println("GossipServer [-port <port>] [-expiry <msecs>] [-bindaddress <address>]");
                return;
            }
            if("-port".equals(arg)) {
                port=Integer.parseInt(args[++i]);
                continue;
            }
            if("-expiry".equals(arg)) {
                expiry_time=Long.parseLong(args[++i]);
                continue;
            }
            if("-bindaddress".equals(arg)) {
                address=InetAddress.getByName(args[++i]);
                continue;
            }
            System.out.println("GossipServer [-port <port>] [-expiry <msecs>]");
            return;
        }

        try {

        }
        catch(Throwable ex) {
            System.err.println("GossipServer.main(): " + ex);
        }

        try {
            gossip_server=new GossipServer(port, expiry_time, address);
            gossip_server.run();
        }
        catch(Exception e) {
            System.err.println("GossipServer.main(): " + e);
        }
    }
    */

    public static TIntIntHashMap getFileVersionMapForTestOnly() {
      return FILE_FORMAT_TO_GEMFIRE_VERSION_MAP;
    }

}
