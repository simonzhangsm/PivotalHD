/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2008-12-18 17:34:03 -0800 (Thu, 18 Dec 2008) $
 **/
// $Id: BlockEvent.java,v 1.2 2005/07/17 11:38:05 chrislott Exp $

package com.gemstone.org.jgroups;

/**
 * Trivial object that represents a block event.
 */
public class BlockEvent {
  @Override // GemStoneAddition
    public String toString() {return "BlockEvent";}
}
