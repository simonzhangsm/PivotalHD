/*=========================================================================
 * (c) Copyright 2002-2007, GemStone Systems, Inc. All Rights Reserved.
 * 1260 NW Waterhouse Ave., Suite 200,  Beaverton, OR 97006
 *=========================================================================
 */
package com.gemstone.org.jgroups.stack.tcpserver;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import com.gemstone.gemfire.DataSerializable;

/**
 * A response from the TCP server that it received
 * the shutdown request
 * @author dsmith
 * @since 5.7
 */
public class ShutdownResponse implements DataSerializable {
  private static final long serialVersionUID = -7223807212380360314L;
  public void fromData(DataInput in) throws IOException,
      ClassNotFoundException {
  }

  public void toData(DataOutput out) throws IOException {
  }
}
