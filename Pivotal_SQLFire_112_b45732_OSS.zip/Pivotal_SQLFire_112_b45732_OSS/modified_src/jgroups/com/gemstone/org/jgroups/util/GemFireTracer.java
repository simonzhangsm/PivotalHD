/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2012-10-19 02:58:31 -0700 (Fri, 19 Oct 2012) $
 **/
/**
 * 
 */
package com.gemstone.org.jgroups.util;

import com.gemstone.gemfire.i18n.LogWriterI18n;
import com.gemstone.gemfire.i18n.StringId;
import com.gemstone.gemfire.internal.LogWriterImpl.GemFireThreadGroup;
import com.gemstone.gemfire.internal.i18n.*;
import com.gemstone.gemfire.SystemFailure;
import com.gemstone.gemfire.internal.LocalLogWriter;
import com.gemstone.gemfire.internal.LogWriterImpl;
import com.gemstone.gemfire.internal.security.SecurityLocalLogWriter;
import com.gemstone.gemfire.distributed.internal.membership.jgroup.JGroupMembershipManager;

import java.io.StringWriter;

/**
 * GemFireTracer wraps a GemFire LogWriterI18n and adapts it to the
 * log4j Log interface.  Parts of this class are based on a similar
 * class that was in the 4.1 product.  The log4j interface isn't actually
 * referenced so we don't have to include log4j in the product.
 * 
 * @author bruce schuchardt
 * @since 5.0
 *
 */
public class GemFireTracer {
    /** whether jgroups debugging should be turned on */
    public static boolean DEBUG = JGroupMembershipManager.DEBUG_JAVAGROUPS;

    /** the default log writer for jgroups */
    static LogWriterI18n defaultLogWriter =
      new LocalLogWriter(LogWriterImpl.INFO_LEVEL, System.out);

    protected static final LogWriterI18n defaultSecurityLogWriter =
      new SecurityLocalLogWriter(LogWriterImpl.INFO_LEVEL, System.out);

    /** a thread-local that holds the log writer for the current thread */
    private static LogWriterI18n logWriter = defaultLogWriter;

    /** a thread-local that holds the security log writer for the current thread */
    private static LogWriterI18n securityLogWriter = defaultSecurityLogWriter;

// threadlocals were holding onto logwriters refering to distributedsystems,
// causing a memory leak
//        new InheritableThreadLocal() {
//            protected Object initialValue() {
//                return defaultLogWriter;
//            }
//        };

    /** <code>ThreadGroup</code> to which JGroups threads belong
     */
    // soubhik: removed final qualifier. (#41438)
    // added initialization in JGroupMemberShipManager#createChannel().
    // [sumedh] removed initialization as mentioned above to prevent leaks
    // and instead added back final with daemon property explicitly as false
    // to avoid it being auto-cleaned if the parent group has that as true
    public static final ThreadGroup GROUP;

    static {
      GROUP = new GemFireThreadGroup("JGroups Threads") {
        @Override
        public void uncaughtException(Thread t, Throwable e) {
          if (e instanceof Error && SystemFailure.isJVMFailureError((Error)e)) {
            SystemFailure.setFailure((Error)e); // don't throw
          }
          StringWriter sw = new StringWriter();
          sw.write("Uncaught Exception in thread ");
          sw.write(t.getName());
          GemFireTracer.getLog(GemFireTracer.class).error(
              "ThreadGroup: " + sw.toString(), e);
        }
      };
      // this is a static thread group so do not exit when last thread exits
      // (the property is inherited from parent so explicitly set to false)
      GROUP.setDaemon(false);
    }

    /** the getLog method currently returns the default instance of
        GemFireTracer */
    private static GemFireTracer defaultInstance = new GemFireTracer();
    
    /** jgroups uses this method to get a tracer */
    public static GemFireTracer getLog(Class clz) {
        return defaultInstance;
    }
    
    /** default constructor */
    public GemFireTracer() {
        super();
    }
    
    /** gemfire's GossipServer startup code uses this method to establish
        the log writer */
    public static void setLogWriter(LogWriterI18n writer) {
        setLogWriter(writer, DEBUG);
    }

    /** gemfire uses this to establish a thread's log writer.  For this
        to work properly, it must be done before the channel is created */
    public static void setLogWriter(LogWriterI18n writer, boolean debug) {
        DEBUG = debug;
        defaultLogWriter = writer;
        logWriter = writer;
        //logWriter.set(writer);
    }

    /**
     * gemfire uses this to establish a thread's security log writer.
     */
    public static void setSecurityLogWriter(LogWriterI18n writer) {
      securityLogWriter = writer;
    }

    /** returns the LogWriterI18n for this tracer */
    public LogWriterI18n getLogWriterI18n() {
      return _log();
    }

    /** returns the security LogWriter for this tracer */
    public LogWriterI18n getSecurityLogWriterI18n() {
      return _securityLog();
    }

    /** returns the log writer for this thread */
    private final LogWriterI18n _log() {
        //return (LogWriterI18n)logWriter.get();
        return logWriter;
    }

    /** returns the security log writer for this thread */
    private final LogWriterI18n _securityLog() {
      return securityLogWriter;
    }

    public void debug(Object arg0, Throwable arg1) {
        if (DEBUG) _log().info(JGroupsStrings.ONE_ARG, ""+arg0, arg1);
    }

    public void debug(Object arg0) {
        if (DEBUG) _log().info(JGroupsStrings.ONE_ARG, ""+arg0);
    }

    public void debug(StringId arg0, Object[] arg1, Throwable arg2) {
        if (DEBUG) _log().info(arg0, arg1, arg2);
    }

    public void debug(StringId arg0, Throwable arg1) {
        if (DEBUG) _log().info(arg0, arg1);
    }

    public void debug(StringId arg0, Object[] arg1) {
        if (DEBUG) _log().info(arg0, arg1);
    }

    public void debug(StringId arg0) {
        if (DEBUG) _log().info(arg0);
    }

    public void error(Object arg0, Throwable arg1) {
        _log().error(JGroupsStrings.ONE_ARG, arg0,arg1);
    }

    public void error(Object arg0) {
      _log().error(JGroupsStrings.ONE_ARG, arg0);
    }

    public void error(StringId arg0, Object[] arg1, Throwable arg2) {
        if (DEBUG) _log().error(arg0, arg1, arg2);
    }

    public void error(StringId arg0, Object arg1, Throwable arg2) {
      if (DEBUG) _log().error(arg0, arg1, arg2);
    }

    public void error(StringId arg0, Object[] arg1) {
      if (DEBUG) _log().error(arg0, arg1);
    }
    
    public void error(StringId arg0, Object arg1) {
        if (DEBUG) _log().error(arg0, arg1);
    }

    public void error(StringId arg0, Throwable arg1) {
        if (DEBUG) _log().error(arg0, arg1);
    }

    public void error(StringId arg0) {
        if (DEBUG) _log().error(arg0);
    }

    public void fatal(Object arg0, Throwable arg1) {
        _log().severe(JGroupsStrings.ONE_ARG, arg0, arg1);
    }

    public void fatal(Object arg0) {
        _log().severe(JGroupsStrings.ONE_ARG, arg0);
    }

    public void fatal(StringId arg0, Object[] arg1) {
      if (DEBUG) _log().severe(arg0, arg1);
    }

    public void fatal(StringId arg0, Object[] arg1, Throwable arg2) {
        if (DEBUG) _log().severe(arg0, arg1, arg2);
    }

    public void fatal(StringId arg0, Throwable arg1) {
        if (DEBUG) _log().severe(arg0, arg1);
    }

    public void fatal(StringId arg0) {
        if (DEBUG) _log().severe(arg0);
    }

    public void info(Object arg0, Throwable arg1) {
        if (DEBUG)
          _log().info(JGroupsStrings.ONE_ARG, ""+arg0, arg1);
        else
          _log().fine(""+arg0, arg1);        
    }

    public void info(Object arg0) {
        if (DEBUG)
          _log().info(JGroupsStrings.ONE_ARG, ""+arg0);
        else
          _log().fine(""+arg0);
    }

    public void info(StringId arg0, Object[] arg1, Throwable arg2) {
        if (DEBUG)
          _log().info(arg0, arg1, arg2);
        else
          _log().fine(arg0.toLocalizedString(arg1), arg2);        
    }

    public void info(StringId arg0, Throwable arg1) {
        if (DEBUG)
          _log().info(arg0, arg1);
        else
          _log().fine(arg0.toLocalizedString(), arg1);        
    }

    public void info(StringId arg0, Object[] arg1) {
      if (DEBUG)
        _log().info(arg0, arg1);
      else
        _log().fine(arg0.toLocalizedString(arg1));        
    }
    
    public void info(StringId arg0, Object arg1) {
      this.info(arg0, new Object[] {arg1});        
    }

    public void info(StringId arg0) {
        if (DEBUG)
          _log().info(arg0);
        else
          _log().fine(""+arg0.toLocalizedString());
    }

    public boolean isDebugEnabled() {
        return DEBUG;
    }

    public boolean isErrorEnabled() {
        return _log().errorEnabled();
    }

    public boolean isFatalEnabled() {
        return _log().severeEnabled();
    }

    public boolean isInfoEnabled() {
        if (DEBUG)
          return _log().infoEnabled();
        else
          return _log().fineEnabled();
    }

    public boolean isTraceEnabled() {
        return DEBUG; //_log().finerEnabled();
    }

    public boolean isWarnEnabled() {
        if (DEBUG)
          return _log().warningEnabled();
        else
          return _log().fineEnabled();  // we use fine level logging for jgroups since it's pretty verbose otherwise
    }

    public void trace(Object arg0, Throwable arg1) {
        if (DEBUG) {
          _log().info(JGroupsStrings.ONE_ARG, ""+arg0, arg1);
        }
        else {
          _log().finer(""+arg0, arg1);
        }
    }

    public void trace(Object arg0) {
        if (DEBUG) {
          _log().info(JGroupsStrings.ONE_ARG, ""+arg0);
        }
        else {
          _log().finer(""+arg0);
        }
    }

    public void warn(Object arg0, Throwable arg1) {
        if (DEBUG) {
          _log().warning(JGroupsStrings.ONE_ARG,arg0, arg1);
        }
        else {
          _log().fine(""+arg0,arg1);
        }
    }

    public void warn(Object arg0) {
        if (DEBUG) {
          _log().warning(JGroupsStrings.ONE_ARG,arg0);
        }
        else {
          _log().fine(""+arg0);
        }
    }


    /**
     * Copied from Javagroups' Trace class from v2.0.3<br>
     * Converts an exception stack trace into a java.lang.String
     * @param x an exception
     * @return a string containg the stack trace, null if the exception parameter was null
     */
    public static String getStackTrace(Throwable x) {
        if(x == null)
            return null;
        else {
            java.io.ByteArrayOutputStream bout=new java.io.ByteArrayOutputStream();
            java.io.PrintStream writer=new java.io.PrintStream(bout);
            x.printStackTrace(writer);
            String result=new String(bout.toByteArray());
            return result;
        }
    }

}
