/*=========================================================================
 * (c) Copyright 2002-2007, GemStone Systems, Inc. All Rights Reserved.
 * 1260 NW Waterhouse Ave., Suite 200,  Beaverton, OR 97006
 *=========================================================================
 */
package com.gemstone.org.jgroups.stack.tcpserver;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import com.gemstone.gemfire.DataSerializable;
import com.gemstone.gemfire.DataSerializer;

/**
 * A response from the TCP server with information
 * about the server
 * @author dsmith
 * @since 5.7
 */
public class InfoResponse implements DataSerializable {
  private static final long serialVersionUID = 6249492407448855032L;
  private static String[] info;
  public InfoResponse(String[] info) {
    InfoResponse.info = info;
  }
  
  /** Used by DataSerializer */
  public InfoResponse() {
  }
  
  public String[] getInfo() {
    return info;
  }

  public void fromData(DataInput in) throws IOException,
      ClassNotFoundException {
    info = DataSerializer.readStringArray(in);
  }

  public void toData(DataOutput out) throws IOException {
    DataSerializer.writeStringArray(info, out);
  }
}