package com.gemstone.org.jgroups.stack.tcpserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

import com.gemstone.gemfire.DataSerializer;
import com.gemstone.gemfire.internal.SocketCreator;
import com.gemstone.gemfire.management.ManagementException;
import com.gemstone.org.jgroups.stack.IpAddress;
import com.gemstone.org.jgroups.util.GemFireTracer;

/**
 * Client for the TcpServer. These methods were refactored out of GossipClient,
 * because they are required for the server regardess of whether we are using the 
 * GossipServer or the ServerLocator.
 * 
 * TODO - refactor this to support keep-alive connections to the server. requestToServer
 * probably shouldn't a static method.
 * @author dsmith
 * @since 5.7
 *
 */
public class TcpClient {
  private static final GemFireTracer LOG=GemFireTracer.getLog(TcpClient.class);
  private static final int REQUEST_TIMEOUT = 60 * 2 * 1000;

  /**
   * Stops the TcpServer running on a given host and port
   */
  public static void stop(InetAddress addr, int port) throws java.net.ConnectException {
    try {
      ShutdownRequest request =new ShutdownRequest();
      TcpClient.requestToServer(addr, port, request, REQUEST_TIMEOUT);
    } 
    catch (java.net.ConnectException ce) {
      // must not be running, rethrow so the caller can handle. 
      // In most cases this Exception should be ignored.
      throw ce;
    }
    catch(Exception ex) {
      LOG.error("TcpClient.stop(): exception connecting to locator " + addr + ":" + port + ": " + ex);
    }
  }

  /** Contacts the gossip server running on the given host,
  * and port and gets information about it.  Two <code>String</code>s
  * are returned: the first string is the working directory of the
  * locator and the second string is the product directory of the
  * locator.
  */
  public static String[] getInfo(InetAddress addr, int port) {
    try {
      InfoRequest request = new InfoRequest();
      InfoResponse response = (InfoResponse) TcpClient.requestToServer(addr, port, request, REQUEST_TIMEOUT);
      return response.getInfo();
    } catch (java.net.ConnectException ignore) {
      return null;
    } catch(Exception ex) {
      LOG.error("TcpClient.getInfo(): exception connecting to locator " + addr + ":" + port + ": " + ex);
      return null;
    }
  
  }

  public static Object requestToServer(InetAddress addr, int port, Object request, int timeout) throws IOException, ClassNotFoundException {
    return requestToServer(addr, port, request, timeout, true);
  }
  
  public static Object requestToServer(InetAddress addr, int port, Object request, int timeout, boolean replyExpected) throws IOException, ClassNotFoundException {
    IpAddress ipAddr;
    if (addr == null) {
      ipAddr = new IpAddress(port);
    } else {
      ipAddr = new IpAddress(addr, port); // fix for bug 30810
    }
    Socket sock=SocketCreator.getDefaultInstance().connect(ipAddr.getIpAddress(), ipAddr.getPort(), LOG.getLogWriterI18n(), timeout, null, false);
    sock.setSoTimeout(timeout);
    try {
    DataOutputStream out=new DataOutputStream(sock.getOutputStream());               
  
    out.writeInt(TcpServer.GOSSIPVERSION);
    DataSerializer.writeObject(request, out);
    out.flush();
    
    if (replyExpected) {
        DataInputStream in = new DataInputStream(sock.getInputStream());
        try {
          Object response = DataSerializer.readObject(in);
          return response;
        } catch (EOFException ex) {
          throw new EOFException("Locator at " + ipAddr + " did not respond. This is normal if the locator was shutdown. If it wasn't check its log for exceptions.");
        }
      }
      else {
        return null;
      }
    } finally {
      try {
        sock.close();
      } catch(Exception e) {
        LOG.error("Error closing socket ", e);
      }
    }
  }
  
  private TcpClient() {
    //static class
  }

}
