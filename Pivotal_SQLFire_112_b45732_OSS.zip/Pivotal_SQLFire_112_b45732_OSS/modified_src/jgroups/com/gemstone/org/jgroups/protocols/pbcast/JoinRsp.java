/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2008-12-18 17:34:03 -0800 (Thu, 18 Dec 2008) $
 **/
// $Id: JoinRsp.java,v 1.8 2005/12/08 13:13:07 belaban Exp $

package com.gemstone.org.jgroups.protocols.pbcast;



import com.gemstone.org.jgroups.Global;
import com.gemstone.org.jgroups.View;
import com.gemstone.org.jgroups.util.Streamable;
import com.gemstone.org.jgroups.util.Util;

import java.io.Serializable;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.DataInputStream;


public class JoinRsp implements Serializable, Streamable {
  /** GemStoneAddition - tells joiner to reattempt with new address */
  static final String SHUNNED_ADDRESS = "[internal]Your address is shunned";
  
    View view=null;
    Digest digest=null;
    String fail_reason = null ;  //GemstoneAddition for member authentication failure msg  
    private static final long serialVersionUID = 2949193438640587597L;

    public JoinRsp() {

    }

    public JoinRsp(View v, Digest d) {
        view=v;
        digest=d;
    }
    public JoinRsp(String fail_reason) { //GemstoneAddition 
        this.fail_reason = fail_reason;
    }
    
    public String getFailReason() { //GemstoneAddition 
      return fail_reason;
    }
    
    public void setFailReason(String fail_reason) { //GemstoneAddition 
      this.fail_reason = fail_reason;
    }

    View getView() {
        return view;
    }

    Digest getDigest() {
        return digest;
    }

    public void writeTo(DataOutputStream out) throws IOException {
        Util.writeStreamable(view, out);
        Util.writeStreamable(digest, out);
        Util.writeString(fail_reason, out);
    }

    public void readFrom(DataInputStream in) throws IOException, IllegalAccessException, InstantiationException {
        view=(View)Util.readStreamable(View.class, in);
        digest=(Digest)Util.readStreamable(Digest.class, in);
        fail_reason=Util.readString(in);
    }

    public int serializedSize() {
        int retval=Global.BYTE_SIZE * 2; // presence for view and digest
        if(view != null)
            retval+=view.serializedSize();
        if(digest != null)
            retval+=digest.serializedSize();
        return retval;
    }

    @Override // GemStoneAddition
    public String toString() {
        StringBuffer sb=new StringBuffer();
        sb.append("view: ");
        if(view == null)
            sb.append("<null>");
        else
            sb.append(view);
        sb.append(", digest: ");
        if(digest == null)
            sb.append("<null>");
        else
            sb.append(digest);
        sb.append(", fail_reason: ");
        if(fail_reason == null)
            sb.append("<null>");
        else
            sb.append(fail_reason);
        return sb.toString();
    }
}
