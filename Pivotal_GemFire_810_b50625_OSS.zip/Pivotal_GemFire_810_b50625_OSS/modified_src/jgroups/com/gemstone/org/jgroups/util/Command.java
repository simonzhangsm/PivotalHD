/** Notice of modification as required by the LGPL
 *  This file was modified by Gemstone Systems Inc. on
 *  $Date: 2008-08-05 12:24:35 -0700 (Tue, 05 Aug 2008) $
 **/
// $Id: Command.java,v 1.2 2005/07/17 11:33:58 chrislott Exp $

package com.gemstone.org.jgroups.util;

/**
  * The Command patttern (see Gamma et al.). Implementations would provide their
  * own <code>execute</code> method.
  * @author Bela Ban
  */
public interface Command {
    boolean execute();
}
